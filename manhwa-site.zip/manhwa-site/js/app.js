/* ============================================================
   ManhwaVault — App Logic  (app.js)
   ============================================================ */

// ── HOME PAGE ───────────────────────────────────────────────
function initHomePage() {
  if (!requireAuth()) return;
  injectNavbar("Home");
  injectFooter();

  // Hero stats counter animation
  animateCounters();

  // Featured manhwa
  renderFeatured();

  // Recently added
  renderSection("recentGrid", getRecent(8));

  // Top rated
  renderSection("topRatedGrid", getTopRated(8));

  // Genre showcase
  renderGenreShowcase();
}

function animateCounters() {
  document.querySelectorAll("[data-count]").forEach(el => {
    const target = parseInt(el.dataset.count, 10);
    let current = 0;
    const step  = Math.ceil(target / 50);
    const timer = setInterval(() => {
      current = Math.min(current + step, target);
      el.textContent = current.toLocaleString();
      if (current >= target) clearInterval(timer);
    }, 30);
  });
}

function renderFeatured() {
  const m = getFeatured();
  const container = document.getElementById("featuredBanner");
  if (!container) return;
  const genre = getGenre(m.genre);
  container.innerHTML = `
    <div class="featured-cover">
      <div class="card-cover-placeholder" style="background:${m.gradient}; width:100%; height:100%; display:flex; flex-direction:column; align-items:center; justify-content:center; padding:12px; position:relative;">
        <div style="font-family:'Cinzel',serif; font-size:0.65rem; font-weight:700; color:rgba(255,255,255,0.9); text-align:center; z-index:1; line-height:1.3;">${m.title}</div>
        <div style="font-size:2.2rem; opacity:0.25; position:absolute; bottom:6px; right:6px; font-family:serif; color:${m.accentColor};">${m.kanji}</div>
      </div>
    </div>
    <div class="featured-info">
      <h2>${m.title}</h2>
      <div class="featured-meta">
        <span class="featured-meta-item">✍️ <strong>${m.author}</strong></span>
        <span class="featured-meta-item">⭐ <strong style="color:var(--accent-gold)">${m.rating}</strong></span>
        <span class="featured-meta-item" style="color:${m.accentColor}">${genre.icon} <strong>${genre.label}</strong></span>
        <span class="featured-meta-item">📖 <strong>${m.chapters} chapters</strong></span>
      </div>
      <p class="featured-desc">${m.description}</p>
      <div style="display:flex; gap:10px; flex-wrap:wrap;">
        <button class="btn btn-primary" onclick="openManhwaModal(${m.id})">View Details</button>
        <button class="btn btn-secondary" onclick="showToast('Added to reading list! 📚', 'success')">+ Add to List</button>
      </div>
    </div>
  `;
}

function renderSection(containerId, manhwas) {
  const container = document.getElementById(containerId);
  if (!container) return;
  container.innerHTML = manhwas.map(m => renderCard(m)).join("");
}

function renderGenreShowcase() {
  const container = document.getElementById("genreShowcase");
  if (!container) return;
  const counts = genreCounts();
  container.innerHTML = GENRES.map((g, i) =>
    renderGenreCard(g, counts[g.id] || 0, i * 0.06)
  ).join("");
}

// ── GENRES PAGE ─────────────────────────────────────────────
function initGenresPage() {
  if (!requireAuth()) return;
  injectNavbar("Genres");
  injectFooter();

  // Read preferred genre from cookie or URL param
  const params   = new URLSearchParams(window.location.search);
  const urlGenre = params.get("genre");
  const savedGenre = Cookies.get("preferred_genre");
  const activeGenre = urlGenre || savedGenre || "all";

  renderGenreChips(activeGenre);
  renderGenreCards(activeGenre);

  // Bind chip clicks
  document.getElementById("genreChips")?.addEventListener("click", e => {
    const chip = e.target.closest(".genre-chip");
    if (!chip) return;
    const gid = chip.dataset.genre;
    // Save preference in cookie
    Cookies.set("preferred_genre", gid);
    document.querySelectorAll(".genre-chip").forEach(c => c.classList.remove("active"));
    chip.classList.add("active");
    renderGenreCards(gid);
  });
}

function renderGenreChips(active) {
  const container = document.getElementById("genreChips");
  if (!container) return;
  const allChip = `<button class="genre-chip${active === "all" ? " active" : ""}" data-genre="all">All Genres</button>`;
  const chips = GENRES.map(g => `
    <button class="genre-chip${active === g.id ? " active" : ""}" data-genre="${g.id}">${g.icon} ${g.label}</button>
  `).join("");
  container.innerHTML = allChip + chips;
}

function renderGenreCards(genreId) {
  const container = document.getElementById("genreResultsGrid");
  const countEl   = document.getElementById("genreResultCount");
  if (!container) return;

  const list = getManhwasByGenre(genreId);
  if (countEl) countEl.textContent = `${list.length} title${list.length !== 1 ? "s" : ""}`;

  if (list.length === 0) {
    container.innerHTML = `<div class="empty-state" style="grid-column:1/-1;"><div class="empty-state-icon">📭</div><h3>No manhwas found</h3><p>Try a different genre.</p></div>`;
    return;
  }
  container.innerHTML = list.map(m => renderCard(m)).join("");
}

// ── COLLECTION PAGE ─────────────────────────────────────────
function initCollectionPage() {
  if (!requireAuth()) return;
  injectNavbar("Collection");
  injectFooter();

  let filtered = [...MANHWA_DATA];

  const searchInput  = document.getElementById("searchInput");
  const sortSelect   = document.getElementById("sortSelect");
  const statusSelect = document.getElementById("statusFilter");
  const genreSelect  = document.getElementById("genreFilter");

  function update() {
    let list = [...MANHWA_DATA];

    // Search
    const q = searchInput?.value.trim().toLowerCase();
    if (q) list = list.filter(m =>
      m.title.toLowerCase().includes(q) ||
      m.author.toLowerCase().includes(q) ||
      m.tags.some(t => t.includes(q))
    );

    // Status filter
    const status = statusSelect?.value;
    if (status && status !== "all") list = list.filter(m => m.status === status);

    // Genre filter
    const genre = genreSelect?.value;
    if (genre && genre !== "all") list = list.filter(m => m.genres.includes(genre));

    // Sort
    list = sortManhwa(list, sortSelect?.value || "rating-desc");

    filtered = list;
    renderCollectionGrid(list);
    document.getElementById("resultCount").textContent = `${list.length} titles`;
  }

  searchInput?.addEventListener("input", update);
  sortSelect?.addEventListener("change", update);
  statusSelect?.addEventListener("change", update);
  genreSelect?.addEventListener("change", update);

  // Populate genre filter
  const genreFilter = document.getElementById("genreFilter");
  if (genreFilter) {
    genreFilter.innerHTML = `<option value="all">All Genres</option>` +
      GENRES.map(g => `<option value="${g.id}">${g.label}</option>`).join("");
  }

  update();
}

function renderCollectionGrid(list) {
  const grid = document.getElementById("collectionGrid");
  if (!grid) return;

  if (list.length === 0) {
    grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1;"><div class="empty-state-icon">🔍</div><h3>No results found</h3><p>Try adjusting your search or filters.</p></div>`;
    return;
  }
  grid.innerHTML = list.map(m => renderCard(m)).join("");
}

// ── SUBMIT PAGE ─────────────────────────────────────────────
function initSubmitPage() {
  if (!requireAuth()) return;
  injectNavbar("Submit");
  injectFooter();

  const form      = document.getElementById("submitForm");
  const preview   = document.getElementById("coverPreview");
  const fileInput = document.getElementById("coverFile");
  const dropZone  = document.getElementById("dropZone");

  // Star rating
  document.querySelectorAll(".star-rating label").forEach(label => {
    label.addEventListener("mouseover", () => {
      const val = label.getAttribute("for").replace("star", "");
      highlightStars(parseInt(val));
    });
    label.addEventListener("mouseleave", () => {
      const checked = document.querySelector(".star-rating input:checked");
      highlightStars(checked ? parseInt(checked.value) : 0);
    });
  });

  function highlightStars(count) {
    document.querySelectorAll(".star-rating label").forEach((l, i) => {
      l.style.color = i < count ? "var(--accent-gold)" : "var(--text-muted)";
    });
  }

  // File upload preview
  function handleFile(file) {
    if (!file || !file.type.startsWith("image/")) {
      showToast("Please upload a valid image file.", "default");
      return;
    }
    const reader = new FileReader();
    reader.onload = e => {
      if (preview) {
        preview.innerHTML = `<img src="${e.target.result}" style="width:100%;height:100%;object-fit:cover;border-radius:8px;" alt="Cover preview">`;
      }
      document.querySelector(".file-upload-text").textContent = file.name;
    };
    reader.readAsDataURL(file);
  }

  fileInput?.addEventListener("change", e => handleFile(e.target.files[0]));

  // Drag & drop
  dropZone?.addEventListener("dragover", e => { e.preventDefault(); dropZone.classList.add("drag-over"); });
  dropZone?.addEventListener("dragleave", () => dropZone.classList.remove("drag-over"));
  dropZone?.addEventListener("drop", e => {
    e.preventDefault();
    dropZone.classList.remove("drag-over");
    handleFile(e.dataTransfer.files[0]);
  });

  // Live preview panel
  const titleInput = document.getElementById("titleInput");
  const authorInput = document.getElementById("authorInput");
  const genreSelect = document.getElementById("genreSelect");
  const descInput   = document.getElementById("descInput");

  [titleInput, authorInput, genreSelect, descInput].forEach(el => {
    el?.addEventListener("input", updateLivePreview);
    el?.addEventListener("change", updateLivePreview);
  });

  function updateLivePreview() {
    const titleEl  = document.getElementById("previewTitle");
    const authorEl = document.getElementById("previewAuthor");
    const genreEl  = document.getElementById("previewGenre");
    const descEl   = document.getElementById("previewDesc");

    if (titleEl)  titleEl.textContent  = titleInput?.value  || "Title";
    if (authorEl) authorEl.textContent = authorInput?.value || "Author";
    if (genreEl) {
      const gid    = genreSelect?.value;
      const genre  = getGenre(gid);
      genreEl.textContent  = genre ? genre.label : "Genre";
      genreEl.style.color  = genre ? genre.color : "var(--accent-red)";
    }
    if (descEl) descEl.textContent = descInput?.value || "Description will appear here...";
  }

  // Form submit (POST simulation)
  form?.addEventListener("submit", async (e) => {
    e.preventDefault();

    if (!validateSubmitForm()) return;

    const submitBtn = document.getElementById("submitBtn");
    submitBtn.textContent = "Submitting...";
    submitBtn.disabled = true;

    // Simulate POST request
    const formData = new FormData(form);
    const payload = {};
    formData.forEach((val, key) => { payload[key] = val; });

    console.log("POST /api/manhwa (simulated):", payload);

    // Fake network delay
    await new Promise(r => setTimeout(r, 1200));

    showToast(`"${payload.title}" submitted successfully! 🎉`, "success");
    form.reset();
    if (preview) preview.innerHTML = `<div style="text-align:center; color:var(--text-muted); font-size:0.8rem;">Cover preview</div>`;
    highlightStars(0);
    submitBtn.textContent = "Submit Manhwa";
    submitBtn.disabled = false;
    updateLivePreview();
  });

  // Populate genre select
  if (genreSelect) {
    genreSelect.innerHTML = `<option value="">Select a genre</option>` +
      GENRES.map(g => `<option value="${g.id}">${g.icon} ${g.label}</option>`).join("");
  }

  updateLivePreview();
}

function validateSubmitForm() {
  const fields = [
    { id: "titleInput",  label: "Title" },
    { id: "authorInput", label: "Author" },
    { id: "genreSelect", label: "Genre" },
    { id: "descInput",   label: "Description" }
  ];

  for (const f of fields) {
    const el = document.getElementById(f.id);
    if (!el || !el.value.trim()) {
      showToast(`Please fill in the ${f.label} field.`, "default");
      el?.focus();
      return false;
    }
  }

  const rating = document.querySelector(".star-rating input:checked");
  if (!rating) {
    showToast("Please select a rating.", "default");
    return false;
  }

  return true;
}

// ── PROFILE PAGE ────────────────────────────────────────────
function initProfilePage() {
  if (!requireAuth()) return;
  injectNavbar("Profile");
  injectFooter();

  // Load saved preferences
  loadPreferences();

  // Preferences form
  document.getElementById("savePrefsBtn")?.addEventListener("click", savePreferences);

  // Populate genre select in preferences
  const genrePref = document.getElementById("prefGenre");
  if (genrePref) {
    genrePref.innerHTML = `<option value="">No preference</option>` +
      GENRES.map(g => `<option value="${g.id}">${g.icon} ${g.label}</option>`).join("");
    const saved = Cookies.get("preferred_genre");
    if (saved) genrePref.value = saved;
  }

  // Reading stats
  renderReadingStats();
}

function loadPreferences() {
  const theme    = Cookies.get("mv_theme")    || "dark";
  const density  = Cookies.get("mv_density")  || "comfortable";
  const username = localStorage.getItem("mv_username") || "Manhwa Lover";

  const nameEl    = document.getElementById("profileName");
  const themeEl   = document.getElementById("prefTheme");
  const densityEl = document.getElementById("prefDensity");

  if (nameEl)    nameEl.textContent   = username;
  if (themeEl)   themeEl.value        = theme;
  if (densityEl) densityEl.value      = density;

  const usernameInput = document.getElementById("usernameInput");
  if (usernameInput) usernameInput.value = username;
}

function savePreferences() {
  const username = document.getElementById("usernameInput")?.value.trim();
  const theme    = document.getElementById("prefTheme")?.value;
  const density  = document.getElementById("prefDensity")?.value;
  const genre    = document.getElementById("prefGenre")?.value;

  if (username) {
    localStorage.setItem("mv_username", username);
    const nameEl = document.getElementById("profileName");
    if (nameEl) nameEl.textContent = username;
  }

  if (theme)   Cookies.set("mv_theme",   theme);
  if (density) Cookies.set("mv_density", density);
  if (genre)   Cookies.set("preferred_genre", genre);

  showToast("Preferences saved! ✓", "success");
}

function renderReadingStats() {
  // Use sessionStorage to track "viewed" items
  const viewed = JSON.parse(sessionStorage.getItem("mv_viewed") || "[]");

  const statsGrid = document.getElementById("readingStats");
  if (!statsGrid) return;

  const completed = MANHWA_DATA.filter(m => m.status === "Completed").length;
  const ongoing   = MANHWA_DATA.filter(m => m.status === "Ongoing").length;
  const totalCh   = MANHWA_DATA.reduce((acc, m) => acc + m.chapters, 0);

  statsGrid.innerHTML = `
    <div class="stat-badge">
      <div class="stat-icon red">📚</div>
      <div>
        <div class="stat-value">${MANHWA_DATA.length}</div>
        <div class="stat-label">Total in Vault</div>
      </div>
    </div>
    <div class="stat-badge">
      <div class="stat-icon green">✅</div>
      <div>
        <div class="stat-value">${completed}</div>
        <div class="stat-label">Completed Series</div>
      </div>
    </div>
    <div class="stat-badge">
      <div class="stat-icon blue">🔵</div>
      <div>
        <div class="stat-value">${ongoing}</div>
        <div class="stat-label">Ongoing Series</div>
      </div>
    </div>
    <div class="stat-badge">
      <div class="stat-icon gold">⭐</div>
      <div>
        <div class="stat-value">${totalCh.toLocaleString()}</div>
        <div class="stat-label">Total Chapters</div>
      </div>
    </div>
  `;
}

// ── GET SAMPLE DATA (simulated GET) ────────────────────────
async function fetchSampleData(endpoint) {
  /* Simulates a GET /api/... request using local data */
  console.log(`GET ${endpoint} (simulated)`);
  await new Promise(r => setTimeout(r, 200)); // fake network delay
  switch (endpoint) {
    case "/api/manhwa":       return { data: MANHWA_DATA, total: MANHWA_DATA.length };
    case "/api/genres":       return { data: GENRES };
    case "/api/featured":     return { data: getFeatured() };
    default:                  return { data: null, error: "Not found" };
  }
}

// ── Auto-init based on page ─────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  const path = window.location.pathname.toLowerCase();

  if (path.includes("index") || path === "/" || path.endsWith("index.html")) {
    initLoginPage();
  } else if (path.includes("home")) {
    initHomePage();
  } else if (path.includes("genre")) {
    initGenresPage();
  } else if (path.includes("collection")) {
    initCollectionPage();
  } else if (path.includes("submit")) {
    initSubmitPage();
  } else if (path.includes("profile")) {
    initProfilePage();
  } else {
    // Fallback: try auth + navbar for any page
    if (requireAuth()) {
      injectNavbar("");
      injectFooter();
    }
  }
});
