/* ============================================================
   ManhwaVault — Data & Utilities  (data.js)
   ============================================================ */

// ── Sample Manhwa Dataset ──────────────────────────────────
const MANHWA_DATA = [
  {
    id: 1,
    title: "Solo Leveling",
    author: "Chugong",
    artist: "DUBU",
    genre: "action",
    genres: ["action", "fantasy"],
    rating: 9.8,
    status: "Completed",
    chapters: 179,
    year: 2018,
    description: "In a world where hunters with magical abilities battle deadly monsters, Sung Jinwoo is the weakest of them all—until a mysterious double dungeon changes everything and grants him a unique power to level up infinitely.",
    gradient: "linear-gradient(135deg, #0a0a20 0%, #16213e 50%, #0f3460 100%)",
    accentColor: "#e94560",
    kanji: "獨",
    tags: ["leveling", "dungeons", "op-mc"],
    featured: true
  },
  {
    id: 2,
    title: "Tower of God",
    author: "SIU",
    artist: "SIU",
    genre: "fantasy",
    genres: ["fantasy", "adventure"],
    rating: 9.2,
    status: "Ongoing",
    chapters: 580,
    year: 2010,
    description: "Bam enters a mysterious tower to find his only friend Rachel. Each floor presents deadly trials—only the worthy climb higher to claim any wish they desire.",
    gradient: "linear-gradient(135deg, #0d1b2a 0%, #1a2744 50%, #0a0f1e 100%)",
    accentColor: "#4a90d9",
    kanji: "塔",
    tags: ["tower", "adventure", "mystery"],
    featured: false
  },
  {
    id: 3,
    title: "True Beauty",
    author: "Yaongyi",
    artist: "Yaongyi",
    genre: "romance",
    genres: ["romance", "slice-of-life"],
    rating: 8.7,
    status: "Completed",
    chapters: 216,
    year: 2018,
    description: "Jugyeong, a girl who transforms herself through makeup, hides her true face from the world—until a chance encounter with a boy who sees through her perfect disguise.",
    gradient: "linear-gradient(135deg, #1a0522 0%, #2d0a3a 50%, #150318 100%)",
    accentColor: "#e879f9",
    kanji: "美",
    tags: ["beauty", "school", "love-triangle"],
    featured: false
  },
  {
    id: 4,
    title: "Sweet Home",
    author: "Carnby Kim",
    artist: "Youngchan Hwang",
    genre: "horror",
    genres: ["horror", "action"],
    rating: 9.0,
    status: "Completed",
    chapters: 140,
    year: 2017,
    description: "A reclusive high schooler is trapped in his apartment complex as humanity transforms into monsters. Survival hinges on whether desire destroys you—or makes you something new.",
    gradient: "linear-gradient(135deg, #0f0800 0%, #1a0f00 50%, #0a0500 100%)",
    accentColor: "#f97316",
    kanji: "宅",
    tags: ["survival", "monsters", "dark"],
    featured: false
  },
  {
    id: 5,
    title: "The Beginning After the End",
    author: "TurtleMe",
    artist: "Fuyuki23",
    genre: "fantasy",
    genres: ["fantasy", "action"],
    rating: 9.4,
    status: "Completed",
    chapters: 178,
    year: 2018,
    description: "King Grey, the most powerful mage in his world, is reborn into a new realm of magic and monsters. This time, he seeks purpose beyond power.",
    gradient: "linear-gradient(135deg, #0a1a0a 0%, #0f2a0f 50%, #051405 100%)",
    accentColor: "#22c55e",
    kanji: "始",
    tags: ["reincarnation", "magic", "kingdom"],
    featured: false
  },
  {
    id: 6,
    title: "God of High School",
    author: "Yongje Park",
    artist: "Yongje Park",
    genre: "martial-arts",
    genres: ["martial-arts", "action"],
    rating: 8.9,
    status: "Ongoing",
    chapters: 590,
    year: 2011,
    description: "Jin Mori enters a martial arts tournament where the winner gets any wish granted. Behind the flashy fights lies a far deeper cosmic conflict.",
    gradient: "linear-gradient(135deg, #1a0a00 0%, #2a1400 50%, #150800 100%)",
    accentColor: "#f59e0b",
    kanji: "神",
    tags: ["tournament", "martial-arts", "gods"],
    featured: false
  },
  {
    id: 7,
    title: "Omniscient Reader",
    author: "Sing Shong",
    artist: "Sleepy-C",
    genre: "action",
    genres: ["action", "fantasy"],
    rating: 9.6,
    status: "Completed",
    chapters: 551,
    year: 2020,
    description: "Kim Dokja is the sole reader of a web novel that predicted the end of civilization—and now he's living inside it. His forbidden knowledge is humanity's last hope.",
    gradient: "linear-gradient(135deg, #08101a 0%, #0f1e2d 50%, #060e16 100%)",
    accentColor: "#38bdf8",
    kanji: "読",
    tags: ["novel", "apocalypse", "knowledge"],
    featured: false
  },
  {
    id: 8,
    title: "Lookism",
    author: "Taejun Pak",
    artist: "Taejun Pak",
    genre: "slice-of-life",
    genres: ["slice-of-life", "action"],
    rating: 8.8,
    status: "Ongoing",
    chapters: 480,
    year: 2014,
    description: "Daniel Park, bullied for his looks, wakes up to find he now has two bodies—one ugly, one impossibly handsome. A razor-sharp commentary on society's obsession with appearance.",
    gradient: "linear-gradient(135deg, #0a0a18 0%, #141428 50%, #0a0a18 100%)",
    accentColor: "#818cf8",
    kanji: "外",
    tags: ["body-swap", "school", "social"],
    featured: false
  },
  {
    id: 9,
    title: "Martial Peak",
    author: "Momo",
    artist: "Pikapi",
    genre: "martial-arts",
    genres: ["martial-arts", "fantasy"],
    rating: 8.5,
    status: "Completed",
    chapters: 3462,
    year: 2019,
    description: "Yang Kai discovers a black book that sets him on a path toward the peak of martial arts—a journey of thousands of chapters through realms of cultivation and power.",
    gradient: "linear-gradient(135deg, #150a00 0%, #251500 50%, #100800 100%)",
    accentColor: "#dc7918",
    kanji: "武",
    tags: ["cultivation", "xianxia", "long"],
    featured: false
  },
  {
    id: 10,
    title: "Bastard",
    author: "Carnby Kim",
    artist: "Youngchan Hwang",
    genre: "horror",
    genres: ["horror", "thriller"],
    rating: 9.1,
    status: "Completed",
    chapters: 94,
    year: 2014,
    description: "Jin's father is a successful, beloved CEO—and a serial killer. Jin must choose between protecting himself and stopping the man who raised him.",
    gradient: "linear-gradient(135deg, #100000 0%, #1e0000 50%, #0a0000 100%)",
    accentColor: "#ef4444",
    kanji: "悪",
    tags: ["thriller", "psychological", "dark"],
    featured: false
  },
  {
    id: 11,
    title: "Noblesse",
    author: "Jeho Son",
    artist: "Kwangsu Lee",
    genre: "action",
    genres: ["action", "fantasy"],
    rating: 8.6,
    status: "Completed",
    chapters: 544,
    year: 2007,
    description: "Cadis Etrama Di Raizel, a powerful noble, awakens after 820 years and enrolls in high school. Ancient enemies and loyal guardians collide in modern Korea.",
    gradient: "linear-gradient(135deg, #080010 0%, #140020 50%, #060008 100%)",
    accentColor: "#c084fc",
    kanji: "貴",
    tags: ["noble", "vampire", "school"],
    featured: false
  },
  {
    id: 12,
    title: "I Love Yoo",
    author: "Quimchee",
    artist: "Quimchee",
    genre: "romance",
    genres: ["romance", "drama"],
    rating: 8.9,
    status: "Hiatus",
    chapters: 275,
    year: 2017,
    description: "Shin-ae stumbles into the lives of two brothers from an ultra-wealthy family. A slow-burn story about healing, worth, and learning to let people in.",
    gradient: "linear-gradient(135deg, #100510 0%, #1e0a1e 50%, #0a0508 100%)",
    accentColor: "#f472b6",
    kanji: "恋",
    tags: ["slow-burn", "webtoon", "healing"],
    featured: false
  },
  {
    id: 13,
    title: "Return of the Mount Hua Sect",
    author: "Bichu",
    artist: "Nini",
    genre: "martial-arts",
    genres: ["martial-arts", "action"],
    rating: 9.3,
    status: "Ongoing",
    chapters: 160,
    year: 2021,
    description: "The greatest swordsman of the Mount Hua Sect dies defeating a demon god and reincarnates 100 years later as a child disciple. He will restore his sect's lost glory.",
    gradient: "linear-gradient(135deg, #0a1400 0%, #14200a 50%, #080f00 100%)",
    accentColor: "#a3e635",
    kanji: "劍",
    tags: ["reincarnation", "sect", "sword"],
    featured: false
  },
  {
    id: 14,
    title: "Cheese in the Trap",
    author: "Soonkki",
    artist: "Soonkki",
    genre: "romance",
    genres: ["romance", "slice-of-life"],
    rating: 8.8,
    status: "Completed",
    chapters: 286,
    year: 2010,
    description: "Hong Seol, a diligent college student, finds herself drawn into the orbit of the perfect-seeming Yoo Jung—and starts to question if perfection hides something darker.",
    gradient: "linear-gradient(135deg, #100a00 0%, #1e1400 50%, #0a0700 100%)",
    accentColor: "#fbbf24",
    kanji: "罠",
    tags: ["college", "psychological", "slow"],
    featured: false
  },
  {
    id: 15,
    title: "Chronicles of Heavenly Demon",
    author: "Cheol Hyeon Mu",
    artist: "Hwajin",
    genre: "martial-arts",
    genres: ["martial-arts", "fantasy"],
    rating: 9.1,
    status: "Completed",
    chapters: 211,
    year: 2020,
    description: "A righteous sect disciple is forced to consume a demonic core and join the enemy. From within the Demonic Cult, he will unravel the conspiracy that destroyed his home.",
    gradient: "linear-gradient(135deg, #0f0000 0%, #1a0500 50%, #090000 100%)",
    accentColor: "#f87171",
    kanji: "魔",
    tags: ["demonic", "cultivation", "revenge"],
    featured: false
  }
];

// ── Genre Configuration ────────────────────────────────────
const GENRES = [
  { id: "action",       label: "Action",       icon: "⚔️",  color: "#e63946", bgColor: "rgba(230,57,70,0.15)" },
  { id: "fantasy",      label: "Fantasy",      icon: "✨",  color: "#818cf8", bgColor: "rgba(129,140,248,0.12)" },
  { id: "romance",      label: "Romance",      icon: "💕",  color: "#f472b6", bgColor: "rgba(244,114,182,0.12)" },
  { id: "horror",       label: "Horror",       icon: "👁️", color: "#f97316", bgColor: "rgba(249,115,22,0.12)" },
  { id: "martial-arts", label: "Martial Arts", icon: "🥊",  color: "#f59e0b", bgColor: "rgba(245,158,11,0.12)" },
  { id: "slice-of-life",label: "Slice of Life",icon: "🌸",  color: "#34d399", bgColor: "rgba(52,211,153,0.12)" },
  { id: "thriller",     label: "Thriller",     icon: "🔪",  color: "#94a3b8", bgColor: "rgba(148,163,184,0.12)" },
  { id: "adventure",    label: "Adventure",    icon: "🗺️", color: "#38bdf8", bgColor: "rgba(56,189,248,0.12)" }
];

// ── Utility Functions ──────────────────────────────────────

/**
 * Get genre config object by id
 */
function getGenre(id) {
  return GENRES.find(g => g.id === id) || GENRES[0];
}

/**
 * Get manhwas filtered by genre
 */
function getManhwasByGenre(genreId) {
  if (!genreId || genreId === "all") return MANHWA_DATA;
  return MANHWA_DATA.filter(m => m.genres.includes(genreId));
}

/**
 * Get the featured manhwa
 */
function getFeatured() {
  return MANHWA_DATA.find(m => m.featured) || MANHWA_DATA[0];
}

/**
 * Get top rated manhwas (sorted by rating desc)
 */
function getTopRated(limit = 8) {
  return [...MANHWA_DATA].sort((a, b) => b.rating - a.rating).slice(0, limit);
}

/**
 * Get recently added (sorted by id desc — newest first in our mock)
 */
function getRecent(limit = 8) {
  return [...MANHWA_DATA].sort((a, b) => b.id - a.id).slice(0, limit);
}

/**
 * Search manhwas by title or author
 */
function searchManhwa(query) {
  const q = query.toLowerCase().trim();
  if (!q) return MANHWA_DATA;
  return MANHWA_DATA.filter(m =>
    m.title.toLowerCase().includes(q) ||
    m.author.toLowerCase().includes(q) ||
    m.tags.some(t => t.includes(q))
  );
}

/**
 * Sort manhwas
 */
function sortManhwa(list, by) {
  const arr = [...list];
  switch (by) {
    case "rating-desc":  return arr.sort((a, b) => b.rating - a.rating);
    case "rating-asc":   return arr.sort((a, b) => a.rating - b.rating);
    case "title-asc":    return arr.sort((a, b) => a.title.localeCompare(b.title));
    case "title-desc":   return arr.sort((a, b) => b.title.localeCompare(a.title));
    case "chapters-desc":return arr.sort((a, b) => b.chapters - a.chapters);
    case "year-desc":    return arr.sort((a, b) => b.year - a.year);
    default:             return arr;
  }
}

/**
 * Render a manhwa card HTML string
 */
function renderCard(manhwa, size = "normal") {
  const genre = getGenre(manhwa.genre);
  const statusClass = manhwa.status === "Completed" ? "status-completed"
                     : manhwa.status === "Ongoing"   ? "status-ongoing"
                     : "status-hiatus";

  return `
    <div class="manhwa-card" data-id="${manhwa.id}" onclick="openManhwaModal(${manhwa.id})">
      <div class="card-cover">
        <div class="card-cover-placeholder" style="background: ${manhwa.gradient};">
          <div class="placeholder-title">${manhwa.title}</div>
          <div class="placeholder-kanji" style="color:${manhwa.accentColor}">${manhwa.kanji}</div>
        </div>
        <div class="card-status ${statusClass}">${manhwa.status}</div>
        <div class="card-rating">⭐ ${manhwa.rating}</div>
        <div class="card-overlay">
          <span class="overlay-read">View Details →</span>
        </div>
      </div>
      <div class="card-info">
        <div class="card-title">${manhwa.title}</div>
        <div class="card-meta">
          <span class="card-genre" style="color:${manhwa.accentColor}">${genre.label}</span>
          <span class="card-chapters">${manhwa.chapters} ch.</span>
        </div>
      </div>
    </div>
  `;
}

/**
 * Render a genre showcase card
 */
function renderGenreCard(genre, count, delay = 0) {
  return `
    <a href="genres.html?genre=${genre.id}" class="genre-showcase-card" style="animation-delay:${delay}s;">
      <div class="genre-card-bg" style="background: radial-gradient(ellipse at center, ${genre.color} 0%, transparent 70%);"></div>
      <span class="genre-showcase-icon">${genre.icon}</span>
      <div class="genre-showcase-name" style="color:${genre.color}">${genre.label}</div>
      <div class="genre-showcase-count">${count} titles</div>
    </a>
  `;
}

/**
 * Count manhwas per genre
 */
function genreCounts() {
  const counts = {};
  GENRES.forEach(g => { counts[g.id] = 0; });
  MANHWA_DATA.forEach(m => {
    m.genres.forEach(gid => {
      if (counts[gid] !== undefined) counts[gid]++;
    });
  });
  return counts;
}

// ── Toast Notification ─────────────────────────────────────
function showToast(message, type = "default", duration = 3500) {
  let container = document.querySelector(".toast-container");
  if (!container) {
    container = document.createElement("div");
    container.className = "toast-container";
    document.body.appendChild(container);
  }
  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateX(20px)";
    toast.style.transition = "all 0.3s ease";
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

// ── Modal ──────────────────────────────────────────────────
function openManhwaModal(id) {
  const m = MANHWA_DATA.find(x => x.id === id);
  if (!m) return;
  const genre = getGenre(m.genre);
  const statusClass = m.status === "Completed" ? "status-completed"
                     : m.status === "Ongoing"   ? "status-ongoing"
                     : "status-hiatus";

  const overlay = document.createElement("div");
  overlay.className = "modal-overlay";
  overlay.innerHTML = `
    <div class="modal" style="max-width:680px;">
      <div class="modal-header">
        <h3>${m.title}</h3>
        <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">✕</button>
      </div>
      <div style="display:grid; grid-template-columns: 140px 1fr; gap:24px; align-items:start;">
        <div style="border-radius:10px; overflow:hidden; box-shadow: 0 8px 24px rgba(0,0,0,0.5);">
          <div class="card-cover-placeholder" style="background:${m.gradient}; aspect-ratio:3/4; display:flex; flex-direction:column; align-items:center; justify-content:center; padding:12px;">
            <div style="font-family:'Cinzel',serif; font-size:0.7rem; font-weight:700; color:rgba(255,255,255,0.9); text-align:center; z-index:1;">${m.title}</div>
            <div style="font-size:2.5rem; opacity:0.2; position:absolute; bottom:8px; right:8px; font-family:serif; color:${m.accentColor};">${m.kanji}</div>
          </div>
        </div>
        <div>
          <div style="display:flex; gap:8px; flex-wrap:wrap; margin-bottom:16px;">
            <span class="card-status ${statusClass}">${m.status}</span>
            <span style="background:rgba(255,209,102,0.15); border:1px solid rgba(255,209,102,0.3); border-radius:4px; padding:3px 8px; font-size:0.7rem; color:var(--accent-gold); font-weight:700;">⭐ ${m.rating}/10</span>
            <span style="background:var(--bg-card); border:1px solid var(--border); border-radius:4px; padding:3px 8px; font-size:0.7rem; color:var(--text-muted);">${m.chapters} Chapters</span>
          </div>
          <div style="display:grid; grid-template-columns: 1fr 1fr; gap:10px; margin-bottom:16px; font-size:0.85rem;">
            <div><span style="color:var(--text-muted);">Author:</span> <strong>${m.author}</strong></div>
            <div><span style="color:var(--text-muted);">Year:</span> <strong>${m.year}</strong></div>
            <div><span style="color:var(--text-muted);">Artist:</span> <strong>${m.artist}</strong></div>
            <div><span style="color:var(--text-muted);">Genre:</span> <strong style="color:${m.accentColor}">${genre.label}</strong></div>
          </div>
          <p style="color:var(--text-secondary); font-size:0.875rem; line-height:1.7; margin-bottom:16px;">${m.description}</p>
          <div style="display:flex; gap:6px; flex-wrap:wrap;">
            ${m.tags.map(t => `<span style="background:var(--bg-card); border:1px solid var(--border); border-radius:4px; padding:3px 10px; font-size:0.7rem; color:var(--text-muted);">#${t}</span>`).join("")}
          </div>
        </div>
      </div>
      <div style="display:flex; gap:12px; margin-top:24px; justify-content:flex-end;">
        <button class="btn btn-secondary" onclick="this.closest('.modal-overlay').remove()">Close</button>
        <button class="btn btn-primary" onclick="showToast('Added to your reading list! 📚', 'success'); this.closest('.modal-overlay').remove()">+ Add to List</button>
      </div>
    </div>
  `;
  overlay.addEventListener("click", e => { if (e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);
}

// ── Cookies ────────────────────────────────────────────────
const Cookies = {
  set(name, value, days = 30) {
    const expires = new Date(Date.now() + days * 864e5).toUTCString();
    document.cookie = `${name}=${encodeURIComponent(value)};expires=${expires};path=/`;
  },
  get(name) {
    const match = document.cookie.match(new RegExp(`(?:^|; )${name}=([^;]*)`));
    return match ? decodeURIComponent(match[1]) : null;
  },
  delete(name) {
    document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/`;
  }
};
