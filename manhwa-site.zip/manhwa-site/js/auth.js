/* ============================================================
   ManhwaVault — Auth / Login  (auth.js)
   ============================================================ */

// ── Constants ──────────────────────────────────────────────
const AUTH_CONFIG = {
  // Password for the demo site — change to whatever you like
  PASSWORD: "manhwa2024",

  // sessionStorage key
  SESSION_KEY: "mv_session",

  // Max failed attempts before temporary lockout
  MAX_ATTEMPTS: 5,
  LOCKOUT_MINUTES: 2,

  // Redirect target after successful login
  REDIRECT_URL: "home.html"
};

// ── Floating kanji & tags setup ────────────────────────────
const KANJI_CHARS = ["漫", "画", "韓", "国", "物", "語", "英", "雄", "魔", "剣", "塔", "神", "武", "恋", "夢"];
const GENRE_TAGS  = ["Action", "Romance", "Fantasy", "Horror", "Martial Arts", "Slice of Life", "Adventure", "Thriller"];

function createFloatingElements() {
  const container = document.querySelector(".login-bg");
  if (!container) return;

  // Kanji characters
  KANJI_CHARS.forEach((char, i) => {
    const el = document.createElement("div");
    el.className = "kanji-float";
    el.textContent = char;
    el.style.cssText = `
      left: ${Math.random() * 95}%;
      font-size: ${Math.random() * 60 + 30}px;
      animation-duration: ${Math.random() * 12 + 10}s;
      animation-delay: -${Math.random() * 15}s;
      opacity: 0;
    `;
    container.appendChild(el);
  });

  // Genre floating tags
  const tagsContainer = document.querySelector(".floating-tags") || document.createElement("div");
  tagsContainer.className = "floating-tags";
  document.body.appendChild(tagsContainer);

  GENRE_TAGS.forEach((tag, i) => {
    const el = document.createElement("div");
    el.className = "float-tag";
    el.textContent = tag.toUpperCase();
    el.style.cssText = `
      left: ${Math.random() * 90}%;
      animation-duration: ${Math.random() * 18 + 14}s;
      animation-delay: -${Math.random() * 20}s;
      letter-spacing: 0.15em;
    `;
    tagsContainer.appendChild(el);
  });
}

// ── Auth State Helpers ──────────────────────────────────────
function isLoggedIn() {
  return sessionStorage.getItem(AUTH_CONFIG.SESSION_KEY) === "active";
}

function login() {
  sessionStorage.setItem(AUTH_CONFIG.SESSION_KEY, "active");
  sessionStorage.setItem("mv_login_time", Date.now().toString());
}

function logout() {
  sessionStorage.removeItem(AUTH_CONFIG.SESSION_KEY);
  sessionStorage.removeItem("mv_login_time");
  window.location.href = "index.html";
}

/**
 * Guard: Call at top of every protected page.
 * Redirects to login if not authenticated.
 */
function requireAuth() {
  if (!isLoggedIn()) {
    window.location.href = "index.html";
    return false;
  }
  return true;
}

// ── Lockout helpers ─────────────────────────────────────────
function getAttempts() {
  return parseInt(sessionStorage.getItem("mv_attempts") || "0", 10);
}

function getLockoutEnd() {
  return parseInt(sessionStorage.getItem("mv_lockout_end") || "0", 10);
}

function isLockedOut() {
  return Date.now() < getLockoutEnd();
}

function recordFailedAttempt() {
  const attempts = getAttempts() + 1;
  sessionStorage.setItem("mv_attempts", attempts.toString());
  if (attempts >= AUTH_CONFIG.MAX_ATTEMPTS) {
    const lockoutEnd = Date.now() + AUTH_CONFIG.LOCKOUT_MINUTES * 60 * 1000;
    sessionStorage.setItem("mv_lockout_end", lockoutEnd.toString());
  }
  return attempts;
}

function clearAttempts() {
  sessionStorage.removeItem("mv_attempts");
  sessionStorage.removeItem("mv_lockout_end");
}

// ── Login Page Logic ────────────────────────────────────────
function initLoginPage() {
  // If already logged in → go straight to home
  if (isLoggedIn()) {
    window.location.href = AUTH_CONFIG.REDIRECT_URL;
    return;
  }

  createFloatingElements();

  const form        = document.getElementById("loginForm");
  const pwInput     = document.getElementById("password");
  const loginBtn    = document.getElementById("loginBtn");
  const errorMsg    = document.getElementById("errorMsg");
  const toggleBtn   = document.getElementById("togglePassword");
  const lockMsg     = document.getElementById("lockoutMsg");

  if (!form) return;

  // Password visibility toggle
  if (toggleBtn && pwInput) {
    toggleBtn.addEventListener("click", () => {
      const isText = pwInput.type === "text";
      pwInput.type = isText ? "password" : "text";
      toggleBtn.textContent = isText ? "👁️" : "🙈";
    });
  }

  // Check lockout on load
  checkLockout();

  function checkLockout() {
    if (isLockedOut()) {
      const remaining = Math.ceil((getLockoutEnd() - Date.now()) / 1000);
      showError(`Too many attempts. Try again in ${remaining}s.`);
      loginBtn.disabled = true;
      loginBtn.style.opacity = "0.5";

      const interval = setInterval(() => {
        if (!isLockedOut()) {
          clearInterval(interval);
          clearAttempts();
          hideError();
          loginBtn.disabled = false;
          loginBtn.style.opacity = "1";
          loginBtn.querySelector(".btn-text").textContent = "Enter the Vault";
        } else {
          const rem = Math.ceil((getLockoutEnd() - Date.now()) / 1000);
          showError(`Too many attempts. Try again in ${rem}s.`);
        }
      }, 1000);
    }
  }

  function showError(msg) {
    if (errorMsg) {
      errorMsg.textContent = "⚠ " + msg;
      errorMsg.classList.add("show");
    }
    if (pwInput) {
      pwInput.style.borderColor = "var(--accent-red)";
      pwInput.style.boxShadow = "0 0 0 3px rgba(230,57,70,0.15)";
    }
  }

  function hideError() {
    if (errorMsg) errorMsg.classList.remove("show");
    if (pwInput) {
      pwInput.style.borderColor = "";
      pwInput.style.boxShadow = "";
    }
  }

  // Form submission
  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    // Check lockout
    if (isLockedOut()) { checkLockout(); return; }

    const password = pwInput.value.trim();

    if (!password) {
      showError("Please enter your password.");
      return;
    }

    // Loading state
    loginBtn.classList.add("loading");
    loginBtn.querySelector(".btn-text").textContent = "Verifying...";
    const spinner = document.createElement("span");
    spinner.className = "btn-spinner";
    loginBtn.prepend(spinner);

    // Simulate async validation (300ms)
    await new Promise(r => setTimeout(r, 600));

    if (password === AUTH_CONFIG.PASSWORD) {
      // ✅ Success
      clearAttempts();
      login();
      loginBtn.querySelector(".btn-text").textContent = "Welcome! ✓";
      loginBtn.style.background = "linear-gradient(135deg,#22c55e,#16a34a)";

      setTimeout(() => {
        window.location.href = AUTH_CONFIG.REDIRECT_URL;
      }, 500);

    } else {
      // ❌ Failed
      const attempts = recordFailedAttempt();
      loginBtn.classList.remove("loading");
      spinner.remove();
      loginBtn.querySelector(".btn-text").textContent = "Enter the Vault";

      const remaining = AUTH_CONFIG.MAX_ATTEMPTS - attempts;
      if (remaining > 0) {
        showError(`Incorrect password. ${remaining} attempt${remaining !== 1 ? "s" : ""} remaining.`);
      } else {
        checkLockout();
      }

      // Shake animation on input
      pwInput.style.animation = "none";
      pwInput.offsetHeight; // reflow
      pwInput.style.animation = "shake 0.4s ease";
      pwInput.value = "";
      pwInput.focus();
    }
  });

  // Clear error on type
  pwInput.addEventListener("input", hideError);
}

// ── Shared Navbar (injected into all protected pages) ──────
function injectNavbar(activePage) {
  const nav = document.getElementById("navbar-placeholder");
  if (!nav) return;

  const pages = [
    { href: "home.html",       label: "Home"       },
    { href: "genres.html",     label: "Genres"     },
    { href: "collection.html", label: "Collection" },
    { href: "submit.html",     label: "Submit"     },
    { href: "profile.html",    label: "Profile"    }
  ];

  const links = pages.map(p => {
    const isActive = p.label.toLowerCase() === activePage.toLowerCase();
    return `<a href="${p.href}" class="nav-link${isActive ? " active" : ""}">${p.label}</a>`;
  }).join("");

  nav.innerHTML = `
    <nav class="navbar" id="mainNavbar">
      <div class="nav-container">
        <a href="home.html" class="nav-logo">
          <div class="logo-icon">漫</div>
          <span class="logo-text">ManhwaVault</span>
        </a>
        <div class="nav-links" id="navLinks">${links}</div>
        <div class="nav-actions">
          <button class="btn-icon" title="Search" onclick="document.querySelector('.search-field input')?.focus()">⌕</button>
          <button class="btn-logout" id="logoutBtn">Logout</button>
          <button class="hamburger" id="hamburgerBtn" aria-label="Menu">☰</button>
        </div>
      </div>
    </nav>
    <div class="nav-mobile" id="navMobile">${links}</div>
  `;

  // Logout
  document.getElementById("logoutBtn")?.addEventListener("click", logout);

  // Hamburger
  const hamburger = document.getElementById("hamburgerBtn");
  const mobileNav = document.getElementById("navMobile");
  hamburger?.addEventListener("click", () => {
    mobileNav.classList.toggle("open");
  });

  // Scroll effect
  window.addEventListener("scroll", () => {
    const navbar = document.getElementById("mainNavbar");
    if (navbar) navbar.classList.toggle("scrolled", window.scrollY > 40);
  }, { passive: true });
}

// ── Shared Footer ──────────────────────────────────────────
function injectFooter() {
  const placeholder = document.getElementById("footer-placeholder");
  if (!placeholder) return;

  placeholder.innerHTML = `
    <footer class="footer">
      <div class="footer-inner">
        <div class="footer-brand">
          <a href="home.html" class="nav-logo" style="margin-bottom:12px; display:inline-flex;">
            <div class="logo-icon">漫</div>
            <span class="logo-text">ManhwaVault</span>
          </a>
          <p class="footer-tagline">Your personal archive for the finest Korean webcomics. Curated with care, read with passion.</p>
        </div>
        <div class="footer-col">
          <h4>Navigate</h4>
          <ul>
            <li><a href="home.html">Home</a></li>
            <li><a href="genres.html">Genres</a></li>
            <li><a href="collection.html">Collection</a></li>
            <li><a href="submit.html">Submit</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>Genres</h4>
          <ul>
            <li><a href="genres.html?genre=action">Action</a></li>
            <li><a href="genres.html?genre=romance">Romance</a></li>
            <li><a href="genres.html?genre=fantasy">Fantasy</a></li>
            <li><a href="genres.html?genre=horror">Horror</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>Account</h4>
          <ul>
            <li><a href="profile.html">Profile</a></li>
            <li><a href="#" onclick="logout()">Logout</a></li>
          </ul>
        </div>
      </div>
      <div class="footer-bottom">
        <span>© 2024 ManhwaVault. Personal Collection.</span>
        <span>Built with ♥ for manhwa lovers</span>
      </div>
    </footer>
  `;
}
